from django.conf.urls import url
from django.contrib import admin
from main import views
from django.urls import path

urlpatterns = [
  path("",views.home,name='home'),

  path('fib', views.fib, name='fib'),
]
